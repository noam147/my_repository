import pygame
import time
import playerVSplayer
import computer
gamedisplay = None

def start_game():
    global gamedisplay
    pygame.init()
    gamedisplay = pygame.display.set_mode((600, 800))
    pygame.display.set_caption("yay game")
    gamedisplay.fill(WHITE)

    gamedisplay.fill(BLUE, rect=[200, 100, 225, 75])
    myfont = pygame.font.SysFont("Arial", 35)
    label = myfont.render("select an option", 1, COLOR)
    gamedisplay.blit(label, (200, 100))

    gamedisplay.fill(RED, rect=[30, 480, 175, 50])
    myfont = pygame.font.SysFont("Arial", 30)
    label = myfont.render("player vs player", 1, COLOR)
    gamedisplay.blit(label, (30, 480))
    pygame.display.update()

    gamedisplay.fill(RED, rect=[300, 480, 225, 50])
    myfont = pygame.font.SysFont("Arial", 30)
    label = myfont.render("player vs computer", 1, COLOR)
    gamedisplay.blit(label, (300, 480))
    pygame.display.update()

    gamedisplay.fill(RED, rect=[300,300,100,50])
    myfont = pygame.font.SysFont("Arial", 30)
    label = myfont.render("QUIT", 1, COLOR)
    gamedisplay.blit(label, (300, 300))
    pygame.display.update()


    btn_pos = pygame.Rect(30, 480, 130, 100)
PLAYER = pygame.Rect(30,480,175,50)
COMPUTER = pygame.Rect(300,480,225,50)
QUIT = pygame.Rect(300,300,100,50)
WHITE = (255, 255, 255)
RED = (255,0,0)
BLUE = (0,0,255)
COLOR = (0,0,0)

start_game()
running = True
while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mousePos = pygame.mouse.get_pos()
            if PLAYER.collidepoint(mousePos):
                playerVSplayer.main()
                raise event
            if COMPUTER.collidepoint(mousePos):
                computer.main()
                raise event
            if QUIT.collidepoint(mousePos):
                running = False
                break



