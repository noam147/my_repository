import pygame
import time
import random
COLOR = (255,0,0)
BLACK = (0,0,0)
WHITE = (255,255,255)
open_place = [1,2,3,4,5,6,7,8,9]
check_list = [1, 1, 1, 1, 1, 1, 1, 1, 1]
circleList = [0,0,0,0,0,0,0,0,0]
rect_list =  [0,0,0,0,0,0,0,0,0]
check = 0
displaygame = pygame.display.set_mode((600, 800))
target_rect1 = pygame.Rect(170, 100, 100, 80)
target_rect2 = pygame.Rect(280, 100, 100, 80)
target_rect3 = pygame.Rect(430, 100, 100, 80)
target_rect4 = pygame.Rect(190, 240, 80, 80)
target_rect5 = pygame.Rect(280, 240, 120, 80)
target_rect6 = pygame.Rect(450, 240, 80, 80)
target_rect7 = pygame.Rect(170, 380, 100, 80)
target_rect8 = pygame.Rect(300, 380, 110, 80)
target_rect9 = pygame.Rect(450, 380, 80, 100)
tup1 = (1, 4, 7)
tup2 = (2, 5, 8)
tup3 = (3, 6, 9)
tup4 = (1, 2, 3)
tup5 = (4, 5, 6)
tup6 = (7, 8, 9)
tup7 = (1, 5, 9)
tup8 = (3, 5, 7)
def display(n):
    circleoption(n)
    circleList[n-1] = n
    open_place[n-1] = -1
    check_list[n-1] = 0
def displayRect(n):
    global check
    check_list[n-1] = 0
    check += 1
    recroption(n)
    rect_list[n-1] = n
    open_place[n-1] = -1
def recroption(choice):
    if choice == 1:
        displaygame.fill(BLACK, rect=[190, 100, 70, 70])
        return 1
    if choice == 2:
        displaygame.fill(BLACK, rect=[300, 100, 70, 70])
        return 2
    if choice == 3:
        displaygame.fill(BLACK, rect=[450, 100, 70, 70])
        return 3
    if choice == 4:
        displaygame.fill(BLACK, rect=[190, 240, 70, 70])
        return 4
    if choice == 5:
        displaygame.fill(BLACK, rect=[300, 240, 70, 70])
        return 5
    if choice == 6:
        displaygame.fill(BLACK, rect=[450, 240, 70, 70])
        return 6
    if choice == 7:
        displaygame.fill(BLACK, rect=[190, 380, 70, 70])
        return 7
    if choice == 8:
        displaygame.fill(BLACK, rect=[300, 380, 70, 70])
        return 8
    if choice == 9:
        displaygame.fill(BLACK, rect=[450, 380, 70, 70])
        return 9
def circleoption(choice):
    if choice == 1:
        pygame.draw.circle(displaygame, BLACK, (220, 140), 40)
        return 1
    if choice == 2:
        pygame.draw.circle(displaygame, BLACK, (350, 140), 40)
        return 2
    if choice == 3:
        pygame.draw.circle(displaygame, BLACK, (480, 140), 40)
        return 3
    if choice == 4:
        pygame.draw.circle(displaygame, BLACK, (220, 280), 40)
        return 4
    if choice == 5:
        pygame.draw.circle(displaygame, BLACK, (350, 280), 40)
        return 5
    if choice == 6:
        pygame.draw.circle(displaygame, BLACK, (480, 280), 40)
        return 6
    if choice == 7:
        pygame.draw.circle(displaygame, BLACK, (220, 420), 40)
        return 7
    if choice == 8:
        pygame.draw.circle(displaygame, BLACK, (350, 420), 40)
        return 8
    if choice == 9:
        pygame.draw.circle(displaygame, BLACK, (480, 420), 40)
        return 9
def createBoard(displaygame):
    #displaygame.fill(BLACK, rect=[120, 100, 5, 500])
    displaygame.fill(BLACK, rect=[270, 100, 5, 400])
    displaygame.fill(BLACK, rect=[420, 100, 5, 400])

    displaygame.fill(BLACK, rect=[200, 200, 300, 5])
    displaygame.fill(BLACK, rect=[200, 350, 300, 5])
def check_win(circleList,rect_list, check = 1):

    for i in range(1,9):
        if set(eval("tup{}".format(i))).issubset(circleList):
            myfont = pygame.font.SysFont("Arial", 100)
            mylabel = myfont.render("computer wins!", 1, COLOR)
            displaygame.blit(mylabel, (75, 200))
            pygame.display.update()
            time.sleep(2)
            pygame.quit()
    for i in range(1,9):
        if set(eval("tup{}".format(i))).issubset(rect_list):
            myfont = pygame.font.SysFont("Arial", 100)
            mylabel = myfont.render("player 1 wins!", 1, COLOR)
            displaygame.blit(mylabel, (100, 200))
            pygame.display.update()
            time.sleep(2)
            pygame.quit()
    checkPlace = []
    for num in circleList:
        checkPlace.append(num)
    for num in rect_list:
        checkPlace.append(num)
    checkPlace = sorted(checkPlace)

    contains_all_numbers = all(num in checkPlace for num in range(1, 10))
    if contains_all_numbers or check == 2:
        myfont = pygame.font.SysFont("Arial", 100)
        mylabel = myfont.render("draw!", 1, COLOR)
        displaygame.blit(mylabel, (100, 200))
        pygame.display.update()
        time.sleep(2)
        pygame.quit()
def check_enemy(circleList,rect_list,check_list,open_place):
    if check_list[0] == 1:
        if rect_list[1] and rect_list[2] or rect_list[3] and rect_list[6] or rect_list[4] and rect_list[8]:
            display(1)
            return 1

    if check_list[1] == 1:
        if rect_list[0] and rect_list[2] or rect_list[4] and rect_list[7]:
            display(2)
            return 1

    if check_list[2] == 1:
        if rect_list[0] and rect_list[1] or rect_list[6] and rect_list[4] or rect_list[8] and rect_list[5]:
            display(3)
            return 1

    if check_list[3] == 1:
        if rect_list[4] and rect_list[5] or rect_list[0] and rect_list[6]:

            display(4)
            return 1

    if check_list[4] == 1:
        if rect_list[0] and rect_list[8] or rect_list[6] and rect_list[2] or rect_list[3] and rect_list[5] or rect_list[1] and rect_list[7]:
            display(5)
            return 1

    if check_list[5] == 1:
        if rect_list[4] and rect_list[3] or rect_list[2] and rect_list[8]:
            display(6)
            return 1

    if check_list[6] == 1:
        if rect_list[7] and rect_list[8] or rect_list[0] and rect_list[3] or rect_list[4] and rect_list[2]:
            display(7)
            return 1

    if check_list[7] == 1:
        if rect_list[6] and rect_list[8] or rect_list[4] and rect_list[1]:
            display(8)
            return 1
    if check_list[8] == 1:
        if rect_list[7] and rect_list[6] or rect_list[2] and rect_list[5] or rect_list[4] and rect_list[0]:
            display(9)
            return 1
def coumpter(circleList,rect_list,check_list):
    if check_list[4]:#check if the board is empty - put in the mdl
        display(5)
        return
    if check_list[0] == 1:
        if circleList[1] and circleList[2] or circleList[3] and circleList[6] or circleList[4] and circleList[8]:
            display(1)
            return

    if check_list[1] == 1:
        if circleList[0] and circleList[2] or circleList[4] and circleList[7]:
            display(2)
            return

    if check_list[2] == 1:
        if circleList[0] and circleList[1] or circleList[6] and circleList[4] or circleList[8] and circleList[5]:
            display(3)
            return

    if check_list[3] == 1:
        if circleList[4] and circleList[5] or circleList[0] and circleList[6]:
            display(4)
            return

    if check_list[4] == 1:
        if circleList[0] and circleList[8] or circleList[6] and circleList[2] or circleList[3] and circleList[5] or circleList[1] and circleList[7]:
            display(5)
            return
    if check_list[5] == 1:
        if circleList[4] and circleList[3] or circleList[2] and circleList[8]:
            display(6)
            return
    if check_list[6] == 1:
        if circleList[7] and circleList[8] or circleList[0] and circleList[3] or circleList[4] and circleList[2]:
            display(7)
            return
    if check_list[7] == 1:
        if circleList[6] and circleList[8] or circleList[4] and circleList[1]:
            display(8)
            return
    if check_list[8] == 1:
        if circleList[7] and circleList[6] or circleList[2] and circleList[5] or circleList[4] and circleList[0]:
            display(9)
            return
    check = check_enemy(circleList,rect_list,check_list,open_place)
    check_win(circleList,rect_list)
    if check != 1:
        random_number = -1
        count = 0
        while random_number == -1 or random_number == None:
            if count == 120:
                check_win(circleList,rect_list, 2)
            random_number = random.choice(open_place)
            if random_number != -1:
                display(random_number)
            count +=1


        #mouse_button_down = pygame.event.Event(pygame.MOUSEBUTTONDOWN,  {'pos': (455, 100), 'button': 1})
        #pygame.event.post(mouse_button_down)
        #pygame.event.pump()



# Post the event to the event queue

def main():
    pygame.init()
    displaygame.fill((255, 255, 255))





    myfont = pygame.font.SysFont("Arial", 25)
    mylabel = myfont.render("if you want to lose a turn- click outside the board", 1, BLACK)
    displaygame.blit(mylabel, (9, 40))
    createBoard(displaygame)

    pygame.display.update()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False


            check_win(circleList,rect_list)
            if event.type == pygame.MOUSEBUTTONDOWN:
                mousepos = pygame.mouse.get_pos()

                if target_rect1.collidepoint(mousepos):
                    if check_list[0] == 0:
                        break
                    displayRect(1)
                if target_rect2.collidepoint(mousepos):
                    if check_list[1] == 0:
                        break
                    displayRect(2)
                if target_rect3.collidepoint(mousepos):
                    if check_list[2] == 0:
                        break
                    displayRect(3)
                if target_rect4.collidepoint(mousepos):
                    if check_list[3] == 0:
                        break
                    displayRect(4)
                if target_rect5.collidepoint(mousepos):
                    if check_list[4] == 0:
                        break
                    displayRect(5)
                if target_rect6.collidepoint(mousepos):
                    if check_list[5] == 0:
                        break
                    displayRect(6)
                if target_rect7.collidepoint(mousepos):
                    if check_list[6] == 0:
                        break
                    displayRect(7)
                if target_rect8.collidepoint(mousepos):
                    if check_list[7] == 0:
                        break
                    displayRect(8)
                if target_rect9.collidepoint(mousepos):
                    if check_list[8] == 0:
                        break
                    displayRect(9)
                check_win(circleList,rect_list)
                pygame.display.update()
                time.sleep(0.5)
                coumpter(circleList,rect_list,check_list)

                check_win(circleList,rect_list)


                try:
                    pygame.display.update()
                except Exception as e:
                 pass

    pygame.display.update()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(e)

