/*********************************
* Class: MAGSHIMIM C2			 *
* Week:                			 *
* Name:                          *
* Credits:                       *
**********************************/

#include <stdio.h>
#include "dirent.h"
#include <string.h>
#define IS_VIRUS 1
#define NOT_VIRUS 0
#define BREAK 2
#define REGULAR_SCAN '0'
#define MAX 10000
void orgenizeAlphabet(char* file,char** arrFiles,int countFiles);
int getResultsToFile(int flag,char* fileName,char scanOption,char* folderScan,char* virus,int printOpen,int checkPrecent);
int regrularOpening(FILE* checkFile, FILE* virusFile);
int quickScan(FILE* checkFile, FILE* virusFile,int* checkPresent);
void checkFile(FILE* file);
//function will check the files in the given folder
//input: two parmeters for folder location and virus signature file location
//example: C:\\Users\\Magshimim\\Documents\\folder C:/Users/Magshimim/Documents/KittenVirusSign
int main(int argc, char** argv)
{
	char fileName[MAX] = { 0 };
	char* filenames[MAX] = { 0 };
	int countNumOfFiles = 0;
	int checkPrecent = 0;
	int* pCheckPrecent = &checkPrecent;
	int printOpen = 1;
	int flag = 0;
	char scanOption = '1';
	char filePath[MAX] = { 0 };
	char folderName[MAX] = { 0 };
	strcpy(folderName, argv[1]);
	printf("\n%s", argv[1]);
	printf("\n%s", folderName);
	FILE* virusFile = fopen(argv[2], "rb");
	if (virusFile == NULL)
	{
		printf("Error opening directory of virus file");
		return 5;
	}

	printf("choose- 0 for regular scan, all other keys for quick scan ");
	scanf("%c", &scanOption);
	getchar();
	DIR* d = 0;
	struct dirent* dir = 0;
	d = opendir(folderName);
	if (d == NULL)
	{
		printf("Error opening directory");
		return 1;
	}
	printf("\n");
	while ((dir = readdir(d)) != NULL)
	{
		if (strcmp(dir->d_name, ".") && strcmp(dir->d_name, "..") && dir->d_type != DT_DIR)//delete . and ..
		{

			snprintf(filePath, sizeof(filePath), "%s/%s", folderName, dir->d_name);
			FILE* file = fopen(filePath, "rb");
			
			countNumOfFiles += 1;
			
			strcpy(fileName,dir->d_name);//working
			
			orgenizeAlphabet(fileName, filenames,countNumOfFiles);
			
			
			//fclose(file);
		}


	}
	closedir(d);
	orgenizeAlphabet(fileName, filenames, countNumOfFiles);


	d = 0;
	dir = 0;
	d = opendir(folderName);
	int i = 0;

	while ((dir = readdir(d)) != NULL)
	{
		if (strcmp(dir->d_name, ".") && strcmp(dir->d_name, "..") && dir->d_type != DT_DIR)//delete . and ..
		{
			strcpy(dir->d_name, filenames[i]);//giving dir the value of filenames that arranged with the alphabeta
			i++;
			//printf("dir is now %s", dir->d_name);
			snprintf(filePath, sizeof(filePath), "%s/%s", folderName, dir->d_name);
			
			FILE* file = fopen(filePath, "rb");
			
			printf("\nchecking File name: %s", dir->d_name);


			strcpy(fileName, dir->d_name);//working

			//orgenizeAlphabet(fileName, filenames, countNumOfFiles);
			if (file == NULL)
			{
				printf("NULL ERROR");
				return -2;
			}
			if (scanOption == REGULAR_SCAN)
			{
				flag = regrularOpening(file, virusFile);
			}
			if (scanOption != REGULAR_SCAN)
			{
				flag = quickScan(file, virusFile, pCheckPrecent);

			}

			printOpen = getResultsToFile(flag, dir->d_name, scanOption, argv[1], argv[2], printOpen, checkPrecent);
			fclose(file);
		}


	}
	closedir(d);






	//Write your code here...
	printf("see results on %s/logExample.txt",argv[1]);

	getchar();
	return 0;
}
/*function will scan if the virus founded in file
* input - file to check, the virus file to compare
* output- the flag that shows if virus or not
*/
int regrularOpening(FILE* checkFile, FILE* virusFile)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int flag = 0;
	int check = 2;
	int countVirus = 0;

	fseek(checkFile, 0, SEEK_END);
	long int fileSize = ftell(checkFile);
	fseek(virusFile, 0, SEEK_END);
	long int virusSize = ftell(virusFile);

	fseek(virusFile, 0, SEEK_CUR);
	fseek(virusFile, 0, SEEK_CUR);
	char* checkFileBuffer = (char*)malloc(fileSize);
	char* virusFileBuffer = (char*)malloc(virusSize);//that's get the memory amount
	//printf("sizes are: %d %d\n", fileSize, virusSize);
	fseek(checkFile, 0, SEEK_SET);
	fseek(virusFile, 0, SEEK_SET);


	if (checkFile == NULL)
	{
		printf("\nho no\n");
	}

	size_t bytes_read = fread(checkFileBuffer, 0, MAX, checkFile);
	size_t bytesReadVirus = fread(virusFileBuffer, 0, MAX, virusFile);

	flag = IS_VIRUS;





	fseek(checkFile, 0, SEEK_SET);
	fseek(virusFile, 0, SEEK_SET);

	for (k = 0; k < fileSize;)//k for the bytes of checkFile
	{
		flag = IS_VIRUS;
		//i < virusSize- deleted
		for (i = 0, j = 0; i < virusSize;)//j for the bytes of virusfile and i for 
		{
			if (checkFileBuffer[k] == virusFileBuffer[j])
			{
				fread(checkFileBuffer, 1, MAX, checkFile);
				fread(virusFileBuffer, 1, MAX, virusFile);
				k++;
				j++;
				i++;
				continue;
			}
			else
			{
				flag = NOT_VIRUS;
				if (check % 2 == 0)
				{

					fseek(virusFile, 0, SEEK_SET);
					j = 0;
					check++;
					continue;
				}
				if (check % 2 == 1)
				{
					check++;
				}
				fseek(virusFile, 0, SEEK_SET);
				fread(checkFileBuffer, 1, MAX, checkFile);
				j = 0;
				k++;
				i++;
				break;
			}
		}
		if (flag == IS_VIRUS)
		{
			printf(" infected!\n");
			//printf("\nflag2 is %d\n", flag);
			free(checkFileBuffer);
			free(virusFileBuffer);
			return flag;
		}
	}
	//printf("\nflag2 is %d\n", flag);







	fseek(virusFile, 0, SEEK_SET);
	fseek(checkFile, 0, SEEK_SET);
	i = 0;
	j = 0;

	if (flag != IS_VIRUS)
	{
		printf(" uninfected\n");
	}
	//printf("\ncheck is %d\n", check);
	free(checkFileBuffer);
	free(virusFileBuffer);


}
/*function will scan if the virus founded in file
* input - file to check, the virus file to compare and to check if it was in 20 last/start percents
* output- the flag that shows if virus or not
*/
int quickScan(FILE* checkFile, FILE* virusFile, int* checkPresent)
{
	int checkPlace = 0;
	int i = 0;
	int j = 0;
	int k = 0;
	int flag = 0;
	int check = 2;
	int countVirus = 0;

	fseek(checkFile, 0, SEEK_END);
	long int fileSize = ftell(checkFile);
	fseek(virusFile, 0, SEEK_END);
	long int virusSize = ftell(virusFile);

	fseek(virusFile, 0, SEEK_CUR);
	fseek(virusFile, 0, SEEK_CUR);
	char* checkFileBuffer = (char*)malloc(fileSize);
	char* virusFileBuffer = (char*)malloc(virusSize);//that's get the memory amount
	//printf("sizes are: %d %d\n", fileSize, virusSize);
	fseek(checkFile, 0, SEEK_SET);
	fseek(virusFile, 0, SEEK_SET);
	int checkFirst20Precent = fileSize * 20 / 100;//that's check where is the first20 percent
	int checkLast20Precent = fileSize * 80 / 100;

	if (checkFile == NULL)
	{
		printf("\nho no\n");
	}

	size_t bytes_read = fread(checkFileBuffer, 0, MAX, checkFile);
	size_t bytesReadVirus = fread(virusFileBuffer, 0, MAX, virusFile);

	flag = IS_VIRUS;


	fseek(checkFile, 0, SEEK_SET);
	fseek(virusFile, 0, SEEK_SET);

	for (k = 0; k < checkFirst20Precent;)//k for the bytes of checkFile -check for first 20 precent
	{
		flag = IS_VIRUS;
		//i < virusSize- deleted
		for (i = 0, j = 0; i < virusSize;)//j for the bytes of virusfile and i for 
		{
			if (checkFileBuffer[k] == virusFileBuffer[j])
			{
				if (k > checkFirst20Precent)
				{
					flag = BREAK;
					break;
				}
				fread(checkFileBuffer, 1, MAX, checkFile);
				fread(virusFileBuffer, 1, MAX, virusFile);
				k++;
				j++;
				i++;

				continue;
			}
			else
			{
				flag = NOT_VIRUS;
				if (check % 2 == 0)
				{

					fseek(virusFile, 0, SEEK_SET);
					j = 0;
					check++;
					continue;
				}
				if (check % 2 == 1)
				{
					check++;
				}
				fseek(virusFile, 0, SEEK_SET);
				fread(checkFileBuffer, 1, MAX, checkFile);
				j = 0;
				k++;
				i++;
				break;
			}
		}
		if (flag == BREAK)
		{
			break;
		}
		if (flag == IS_VIRUS)
		{
			printf(" infected in first 20 precent!\n");
			*(checkPresent) = 1;
			free(checkFileBuffer);
			free(virusFileBuffer);
			return flag;
		}
	}




	fseek(checkFile, 0, SEEK_SET);
	fseek(virusFile, 0, SEEK_SET);

	for (k = checkLast20Precent; k < fileSize;)//k for the bytes of checkFile -check for last 20 precent
	{
		flag = IS_VIRUS;
		//i < virusSize- deleted
		for (i = 0, j = 0; i < virusSize;)//j for the bytes of virusfile and i for 
		{
			if (checkFileBuffer[k] == virusFileBuffer[j])
			{
				
				fread(checkFileBuffer, 1, MAX, checkFile);
				fread(virusFileBuffer, 1, MAX, virusFile);
				k++;
				j++;
				i++;

				continue;
			}
			else
			{
				flag = NOT_VIRUS;
				if (check % 2 == 0)
				{

					fseek(virusFile, 0, SEEK_SET);
					j = 0;
					check++;
					continue;
				}
				if (check % 2 == 1)
				{
					check++;
				}
				fseek(virusFile, 0, SEEK_SET);
				fread(checkFileBuffer, 1, MAX, checkFile);
				j = 0;
				k++;
				i++;
				break;
			}
		}
		if (flag == BREAK)
		{
			break;
		}
		if (flag == IS_VIRUS)
		{
			printf(" infected in last 20 precent!\n");
			*(checkPresent) = 2;
			free(checkFileBuffer);
			free(virusFileBuffer);
			return flag;
		}
	}









	fseek(checkFile, 0, SEEK_SET);
	fseek(virusFile, 0, SEEK_SET);

	for (k = 0; k < fileSize;)//k for the bytes of checkFile
	{
		flag = IS_VIRUS;
		//i < virusSize- deleted
		for (i = 0, j = 0; i < virusSize;)//j for the bytes of virusfile and i for 
		{
			if (checkFileBuffer[k] == virusFileBuffer[j])
			{
				fread(checkFileBuffer, 1, MAX, checkFile);
				fread(virusFileBuffer, 1, MAX, virusFile);
				k++;
				j++;
				i++;
				
				continue;
			}
			else
			{
				flag = NOT_VIRUS;
				if (check % 2 == 0)
				{

					fseek(virusFile, 0, SEEK_SET);
					j = 0;
					check++;
					continue;
				}
				if (check % 2 == 1)
				{
					check++;
				}
				fseek(virusFile, 0, SEEK_SET);
				fread(checkFileBuffer, 1, MAX, checkFile);
				j = 0;
				k++;
				i++;
				break;
			}
		}
		if (flag == IS_VIRUS)
		{
			printf(" infected ");
			
			//printf("the last byte was in- %d and the last byte is %d", k,fileSize);


			if (k < checkFirst20Precent)//k is the lasy byte that was the virus ain the file
			{
				*(checkPresent) = 1;
			
				printf("in first 20 precent\n");

			}
			if (k > checkLast20Precent)
			{
				*(checkPresent) = 2;
				
				printf("in last 20 precent\n");

			}


			//printf("\nflag2 is %d\n", flag);
			free(checkFileBuffer);
			free(virusFileBuffer);
			return flag;
		}
	}
	//printf("\nflag2 is %d\n", flag);







	fseek(virusFile, 0, SEEK_SET);
	fseek(checkFile, 0, SEEK_SET);
	i = 0;
	j = 0;

	if (flag != IS_VIRUS)
	{
		printf(" uninfected\n");
	}
	//printf("\ncheck is %d\n", check);
	free(checkFileBuffer);
	free(virusFileBuffer);

}
/*function will get the result of the scan into a file
* input - flag(for fast or rgelur scan) ,name of file,the folder location ,thevirus location,and check in the fast scan if it was in 20 last/start precents
* output- number that checks if we entered this function before
*/
int getResultsToFile(int flag, char* fileName, char scanOption, char* folderScan, char* virus,int printOpen, int checkPrecent)
{
	char filePath[MAX] = { 0 };
	snprintf(filePath, sizeof(filePath), "%s/%s", folderScan,"logExample.txt");


	
	//folderscan + filename
	FILE* resultFile = fopen(filePath, "a");

	if (printOpen == 1)//to print all the start staff
	{
		fclose(resultFile);
		fclose(fopen(filePath, "w"));
		FILE* resultFile = fopen(filePath, "a");
		fprintf(resultFile, "Anti-virus began! Welcome!\nFolder to scan: %s\nVirus signature: %s", folderScan, virus);
		if (scanOption == REGULAR_SCAN)
		{
			fprintf(resultFile, "Scanning option:\nnormal scan\n");
			fprintf(resultFile, "results:\n");
		}
	}

	if (flag == IS_VIRUS)
	{
		if (scanOption == REGULAR_SCAN)
		{
			fprintf(resultFile, "%s - infected!\n",fileName);
		}
		if (scanOption != REGULAR_SCAN)
		{
			if (checkPrecent == 0)
			{
				fprintf(resultFile, "%s - infected!\n", fileName);
			}
			if (checkPrecent == 1)
			{
				fprintf(resultFile, "%s - infected in first 20%!\n", fileName);
			}
			if (checkPrecent == 2)
			{
				fprintf(resultFile, "%s - infected in last 20%!\n", fileName);
			}
		}
	}
	else
	{
		
		
			fprintf(resultFile, "%s - not infected!\n",fileName);
		
	}
	fclose(resultFile);
	return printOpen += 1;
}
/*function will orgnize the files in alphabetic way
* input - name of file, arry that contain all the files,count files
* output- none
*/
void orgenizeAlphabet(char* file, char** arrFiles, int countFiles) 
{
	int i = 0;
	int j = 0;
	if (arrFiles[countFiles-1] == NULL)
	{
		arrFiles[countFiles - 1] = malloc(strlen(file) + 1);
		strcpy(arrFiles[countFiles-1],file);
		return;
	}

	
	for (i = 0; i <countFiles; i++) 
	{

		for (j = 0; j < countFiles-1; j++)
		{
			if (strcmp(arrFiles[j+1], arrFiles[j]) < 0)
			{
				//char temp[MAX] = NULL;
				char* temp = malloc(strlen(arrFiles[j+1]) + 1);

				strcpy(temp, arrFiles[j+1]);
				strcpy(arrFiles[j+1], arrFiles[j]);
				strcpy(arrFiles[j], temp);
				free(temp);
			}
		}	
	}
	
	for (i = 0; i < countFiles; i++)
	{
		//printf("strings are %s\n", arrFiles[i]);
	}

}