import socket
import hashlib
DST_PORT = 9090
DST_IP = "127.0.0.1"

#function will decode the server messages and get them into the user
#input the server msg
#output the msg for the client
def server_msg(msg):
    if msg[:3] == "200":
        check = msg.find("=") +1
        return "albums are " +msg[check :]
    if msg[:3] == "201":
        check = msg.find("=") +1
        if msg[check :] == "":
            return "The album you typed does not exist"
        return "songs are " +msg[check:]
    if msg[:3] == "202":
        check = msg.find("=") +1
        if msg[check :] == "":
            return "The song you typed does not exist"
        return "length is " +msg[check :]
    if msg[:3] == "203":
        check = msg.find("=") +1
        if msg[check :] == "":
            return "The song you typed does not exist"
        return "WORDS OF SONG ARE:\n " +msg[check :]
    if msg[:3] == "204":
        check = msg.find("=") +1
        if msg[check :] == "":
            return "The song you typed does not exist"
        return "the album of the song is: " +msg[check :]
    if msg[:3] == "205":
        check = msg.find("=") +1
        if msg[check :] == "":
            return "there are not songs that include your word in thier title"
        return "all the songs that include your word (in their title) are:\n " +msg[check :]
    if msg[:3] == "206":
        check = msg.find("=") +1
        if msg[check :] == "":
            return "there are not songs that include your word in their lyrics"
        return "all the songs that include your word (in their lyrics) are:\n " +msg[check :]
    if msg[:3] == "207":
        check = msg.find("&")+1
        return msg[check:]
    if msg[:3] == "400":
        check = msg.find(":")+1
        return msg[check:]
    if msg[:3] == "500":
        check = msg.find(":")+1
        return msg[check:]
#function will encode the client messages for the server
#input the choice command
#output the msg for the server
def options(choice):
    if choice == '1':
        return "100REQUEST:GET_ALBUMS"
    if choice == '2':
        album = input("enter an album to get its songs ")
        return "101REQUEST:GET_SONGS&ALBUM="+ album
    if choice == '3':
        song = input("enter a song to get its length ")
        return "102REQUEST:GET_LEN_SONG&SONG="+song
    if choice == '4':
        song = input("enter a song to get its words ")
        return "103REQUEST:GET_WORDS_IN_SONG&SONG="+song
    if choice == '5':
        song = input("enter a song to get its album ")
        return "104REQUEST:GET_ALBUM_BY_SONG&SONG="+song
    if choice == '6':
        word = input("enter a word to see in which songs its appears(just in the title) ").lower()
        return "105REQUEST:GET_SONGS_BY_WORD&WORD="+word
    if choice == '7':
        word = input("enter a word to see in which songs its appears(inside the song words)").lower()
        return "106REQUEST:GET_SONGS_BY_WORD_IN_SONG&WORD="+word
    if choice == '8':
        return "107REQUEST:#EXIT"


def main():
    try:

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_address = (DST_IP, DST_PORT)
        sock.connect(server_address)
        #server_msg = sock.recv(1024)
        #server_msg = server_msg.decode()
    except Exception as e:
        print("error ",e)
        return 1

    opening= "1.GET_ALBUMS\n2.GET_SONGS BY ALBUM\n3.GET_LENGTH OF SONG\n4.GET_WORDS_IN_SONG\n5.GET_ALBUM_FROM_NAME_OF_SONG\n6.GET_SONGS_BY_WORD\n7.GET_SONGS_BY_WORD_IN_SONG\n8.EXIT"
    choice = ""
    print("hello, welcome to pink server")
    flag = 0
    while flag == 0:
        try:
            check_password = input("before entering enter password- ")
            hashed_password = hashlib.sha256(check_password.encode()).hexdigest()
            sock.sendall(hashed_password.encode())
            server_respond = sock.recv(1024)
            server_respond = server_respond.decode()
            print(server_respond)
            if server_respond == "200OK":
                print("user accecpt")
                flag = 1
        except Exception as e:
            print("error ",e)
            return -1

    try:
        while choice != "8":
            print(opening)
            choice = input("enter a command between 1-8 ")
            try:
                if int(choice) > 8 or int(choice) < 1:
                    print("invalid choice enter num from 1 - 8")
                    continue
            except Exception as e:
                print("invalid choice! just numbers!")
                continue
            msg = options(choice)
            #msg = "105REQUEST:GET_LEN_SONG&SONG=song"
            data = msg.encode()
            sock.sendall(data)
            server_respond = sock.recv(1024)
            server_respond = server_respond.decode()

            current_msg = server_msg(server_respond)
            print(current_msg)
    except Exception as e:
        print("error" ,str(e))
    sock.close()






if __name__ == "__main__":

    main()
