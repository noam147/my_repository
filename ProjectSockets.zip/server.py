import socket
import data
import hashlib
LISTEN_PORT = 9090
DST_PORT = 92
DST_IP = "54.71.128.194"
FILE_PATH = "Pink_Floyd_DB.txt"
HASHED_PASSWORD = hashlib.sha256(b'Magsh1m!m#').hexdigest()

#function will get the details of the txt file that has the data and divid it to sevral lists
#input the albums of the txt file
#output list that contain the data
def get_details(albums):

    count = 0
    value_to_albums = []
    years_of_albums = []
    titles_of_albums = []
    times_of_songs = []
    contents_of_song = []
    for i in albums:
        check_name = i.find("::")
        check_end = i.find("*")
        years_of_albums.append(i[check_name+2:check_end])
        value_to_albums.append(i[:check_name])
        count+= 1
    count = 0

    for i in albums:
        titles_of_albums.append([])
        times_of_songs.append([])
        contents_of_song.append([])
        check_times = i.count("*")
        new_album = i
        for song in range(check_times):

            check_name = new_album.find("*")
            new_album = new_album[check_name+1:]
            check_end = new_album.find("::")
            song_title = new_album[:check_end]
            check_content = new_album.split("::")[3]
            check_end_content = check_content.find("*")
            #print(check_end_content)
            contents_of_song[count].append(check_content[:check_end_content])
            titles_of_albums[count].append(song_title)
            check_start = new_album.find("::", new_album.find("::") + 2) + 2
            check_end2 = new_album.find("::", check_start + 1)
            times_of_songs[count].append(new_album[check_start:check_end2])

        count+= 1

    return value_to_albums, years_of_albums, titles_of_albums, times_of_songs, contents_of_song
#function will encode the server messages for the client and give hi, the data
#input the lists that has the data
#output the msg for the client
def options(dataa,name_of_albums, years_publish_albums,title_of_songs,length_of_songs,content_of_songs):
    if dataa[:3] == "100":
        albums= data.get_albums(name_of_albums)
        return "200ANSWER:GIVE_ALBUMS&ALBUMS="+albums[:-2]
    if dataa[:3] == "107":
        return "207ANSWER:GIVE_NONE&goodbey"
    if dataa.find("=") == -1:
        return "500ERROR:INVALID_REQUEST"
    examplefile = ""
    if dataa[:3] == "101":
        check = dataa.find("=")+1
        album = dataa[check:]
        songs = data.get_songs_by_album(name_of_albums,title_of_songs,album)
        return "201ANSWER:GIVE_SONGS&SONGS="+songs[:-2]
    if dataa[:3] == "102":
        check = dataa.find("=")+1
        song = dataa[check:]
        len_song = data.get_length_of_song(song,title_of_songs,length_of_songs)
        return "202ANSWER:GIVE_LEN_SONG&LENGTH="+len_song
    if dataa[:3] == "103":
        check = dataa.find("=")+1
        song = dataa[check:]
        content = data.get_content_of_song(song,title_of_songs,content_of_songs)
        return "203ANSWER:GIVE_WORDS_IN_SONG&SONG="+content
    if dataa[:3] == "104":
        check = dataa.find("=")+1
        song = dataa[check:]
        album = data.get_the_album_of_song(song,title_of_songs,name_of_albums)
        return "204ANSWER:GIVE_ALBUM_BY_SONG&ALBUM="+album
    if dataa[:3] == "105":
        check = dataa.find("=")+1
        word = dataa[check:]
        songs = data.get_titles_of_songs_by_word(word,title_of_songs)
        return "205ANSWER:GIVE_SONGS_BY_WORD&SONGS="+songs[:-2]
    if dataa[:3] == "106":
        check = dataa.find("=")+1
        word = dataa[check:]
        songs = data.get_songs_by_word_in_content(word,title_of_songs,content_of_songs)
        return "206ANSWER:GIVE_SONGS_BY_WORD_IN_SONG&SONGS="+songs[:-2]


def main():
    #with open(FILE_PATH)
    file = open(FILE_PATH)

    check = file.read().replace("\n"," ").replace("\t","").replace("\\","")
    albums = []
    count = check.count("#")
    albums = check.split("#")
    del albums[0]
    name_of_albums, years_publish_albums,title_of_songs,length_of_songs,content_of_songs = get_details(albums)
    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listening_sock:
            try:
                server_address = ('', LISTEN_PORT)
                listening_sock.bind(server_address)
            except Exception as e:
                print("error ",e)
                break
            print("waiting")
            listening_sock.listen(1)
            client_soc, client_address = listening_sock.accept()
            print("client found")

            flag =0
            while flag == 0:
                try:
                    data = client_soc.recv(1024).decode()
                    if data.strip() == HASHED_PASSWORD:
                        flag = 1
                        client_soc.sendall("200OK".encode())
                    else:
                        client_soc.sendall("incorrect passowrd".encode())
                except Exception as e:
                    print("error ",e)
                    break
            server_msg = ""
            #server_msg= "hello, welcome to pink server\n1.GET_ALBUMS\n2.GET_SONGS BY ALBUM\n3.GET_LENGTH OF SONG\n4.GET_LEN_SONG\n5.GET_WORDS_IN_SONG\n6.GET_SONGS_BY_WORD\n7.GET_SONGS_BY_WORD_IN_SONG\n8.EXIT"
            #client_soc.sendall(server_msg.encode())
            data = ""
            while data != "QUIT":
                try:
                    data = client_soc.recv(1024)
                    data = data.decode()
                except Exception as e:
                    print("error ",e)
                    print("continue to the next client")
                    break
                if data == "QUIT":
                    client_soc.sendall("goodbey".encode())
                    break
                if data[3:10] != "REQUEST":
                    print(data[3:10])
                    server_msg = "500ERROR:INVALID_REQUEST"
                    client_soc.sendall(server_msg.encode())
                    continue


                server_msg = options(data,name_of_albums, years_publish_albums,title_of_songs,length_of_songs,content_of_songs)

                client_soc.sendall(server_msg.encode())
                file.close()


                #client_soc.sendall("data is ".encode() + data.encode())



if __name__ == "__main__":
    main()
