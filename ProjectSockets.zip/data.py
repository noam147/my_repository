FILE_PATH = "Pink_Floyd_DB.txt"

#function will get the details of the txt file that has the data and divid it to sevral lists
#input the albums of the txt file
#output list that contain the data
def get_details(albums):

    count = 0
    value_to_albums = []
    years_of_albums = []
    titles_of_albums = []
    times_of_songs = []
    contents_of_song = []
    for i in albums:
        check_name = i.find("::")
        check_end = i.find("*")
        years_of_albums.append(i[check_name+2:check_end])
        value_to_albums.append(i[:check_name])
        count+= 1
    count = 0

    for i in albums:
        titles_of_albums.append([])
        times_of_songs.append([])
        contents_of_song.append([])
        check_times = i.count("*")
        new_album = i
        for song in range(check_times):

            check_name = new_album.find("*")
            new_album = new_album[check_name+1:]
            check_end = new_album.find("::")
            song_title = new_album[:check_end]
            check_content = new_album.split("::")[3]
            check_end_content = check_content.find("*")
            #print(check_end_content)
            contents_of_song[count].append(check_content[:check_end_content])
            titles_of_albums[count].append(song_title)
            check_start = new_album.find("::", new_album.find("::") + 2) + 2
            check_end2 = new_album.find("::", check_start + 1)
            times_of_songs[count].append(new_album[check_start:check_end2])

        count+= 1

    return value_to_albums, years_of_albums, titles_of_albums, times_of_songs, contents_of_song


    #dict = {album1:[(year),(titleSong1,lensong1,contentsong1),(titleSong2,lensong2,contentsong2)],album2:[(year),(titleSong1,lensong1,contentsong1),(titleSong2,lensong2,contentsong2),(titleSong3,lensong3,contentsong3)]}
    """album1 = [(year),("titleSong1", lensong1, contentsong1), ("titleSong2", lensong2, contentsong2)]
        album2 = [(year),("titleSong1", lensong1, contentsong1), ("titleSong2", lensong2, contentsong2), ("titleSong3", lensong3, contentsong3)]

        my_dict = {"album1": album1, "album2": album2}"""

#function will get the albums of the txtfile
#input list of the albums of the txt file
#output string that contain the data
def get_albums(albums):
    str_albums = ""
    for cell in albums:
        str_albums += cell
        str_albums+= ", "
    return str_albums
#function will get the songs of a specific album
#input name of album,list of the songs
#output string that contain the data
def get_songs_by_album(albums,title_of_songs,album):
    i=0
    j=0
    current_songs = ""
    for cell in albums:
        if cell == album:
            for cell2 in title_of_songs[i]:
                current_songs += title_of_songs[i][j]
                current_songs += ", "
                j+=1

        i+=1

    return current_songs
#function will get the length of a specific song
#input name of song,list of the lengths
#output string that contain the data
def get_length_of_song(title_of_song,title_of_songs,len_of_songs):

    song_len = ""
    for i in range(len(title_of_songs)):
        for j in range(len(title_of_songs[i])):

            if title_of_songs[i][j] == title_of_song:
                song_len = len_of_songs[i][j]
                break  # Exit both loops if condition is met
        else:
            continue
        break
    return song_len
#function will get the content of a specific song
#input name of song,list of the songs contents
#output string that contain the data
def get_content_of_song(song,title_of_songs,content_of_songs):
    song_content = ""
    for i in range(len(title_of_songs)):
        for j in range(len(title_of_songs[i])):

            if title_of_songs[i][j] == song:
                song_content = content_of_songs[i][j]
                break  # Exit both loops if condition is met
        else:
            continue
        break
    return song_content
#function will get album by a specific song
#input name of song,list of the albums
#output string that contain the data
def get_the_album_of_song(song,title_of_songs,name_of_albums):
    album = ""
    for i in range(len(title_of_songs)):
        for j in range(len(title_of_songs[i])):
            if title_of_songs[i][j] == song:
                album = name_of_albums[i]
    return album
#function will get all the songs that contain a specific word in their titles
#input word,list of songs
#output string that contain the data
def get_titles_of_songs_by_word(word,title_of_songs):
    arr_title_songs = []
    my_str = ""
    for i in range(len(title_of_songs)):
        for j in range(len(title_of_songs[i])):
            if word in title_of_songs[i][j]:
                arr_title_songs.append(title_of_songs[i][j])

    for cell in arr_title_songs:
        my_str += str(cell)
        my_str += ", "
    return my_str
#function will get all the songs that contain a specific word in their contents
#input word,list of songs, list of songs contents
#output string that contain the data
def get_songs_by_word_in_content(word,title_of_songs,content_of_songs):
    arr_title_songs = []
    my_str = ""
    for i in range(len(content_of_songs)):
        for j in range(len(content_of_songs[i])):
            if word in content_of_songs[i][j]:
                arr_title_songs.append(title_of_songs[i][j])
    for cell in arr_title_songs:
        my_str += str(cell)
        my_str += ", "
    return my_str






def main():
    with open(FILE_PATH) as file:
        check = file.read().replace("\n"," ").replace("\t","").replace("\\","")

        #print(check)
        #get_albums(check)
        albums = []
        count = check.count("#")
        #print(count)
        albums = check.split("#")
        del albums[0]
        #print(albums)
        name_of_albums, years_publish_albums,title_of_songs,length_of_songs,content_of_songs = get_details(albums)
        #get_albums(name_of_albums) working request one
        #album = "More"
        #get_songs_by_album(name_of_albums,title_of_songs,album)
        #song = "Mother"
        #get_length_of_song(song,title_of_songs,length_of_songs)workingrequest three
        #get_content_of_song(song,title_of_songs,content_of_songs)workingrequest four
        #get_the_album_of_song(song,title_of_songs,name_of_albums) working request five
        #word = "light"
        #get_titles_of_songs_by_word(word,title_of_songs) working request six
        #get_songs_by_word_in_content(word,title_of_songs,content_of_songs)working request seven



if __name__ == "__main__":
    main()
